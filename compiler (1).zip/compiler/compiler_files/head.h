/*  o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o
    o+
    o+     File:         head.h
    o+
    o+     Programmer:   Shaun Flisakowski
    o+     Date:         Aug 12, 1998
    o+
    o+     A comment about the file.
    o+
    o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o+o  */

#ifndef    HEAD_H
#define    HEAD_H

#endif  /* HEAD_H */

