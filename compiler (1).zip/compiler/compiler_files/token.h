
/*  ###############################################################
    ##
    ##     C Tree Builder
    ##
    ##     File:         token.h
    ##
    ##     Programmer:   Shawn Flisakowski
    ##     Date:         Dec 24, 1994
    ##
    ##
    ###############################################################  */

#ifndef    TOKEN_H
#define    TOKEN_H

#include  "config.h"

BEGIN_HEADER

/*  ###############################################################  */

char *toksym    ARGS((int tok, int white));

/*  ###############################################################  */

END_HEADER

#endif    /* TOKEN_H */
