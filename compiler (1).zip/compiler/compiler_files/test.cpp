#include <iostream>
using namespace std;
#include	"CodeGenerator.h"
int main (){
    cout<< "hello";
}