int x=0 ;
