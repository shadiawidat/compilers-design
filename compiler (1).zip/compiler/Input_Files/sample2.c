#include <stdio.h>

void main() {
	printf("%d\n", 5);
	return;
}