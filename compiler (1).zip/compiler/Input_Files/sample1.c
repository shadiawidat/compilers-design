#include <stdio.h>

void main() {
	return;
}