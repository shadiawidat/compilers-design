#include <stdio.h>

void main() {
	double a;
	int c;
	int b;

	a = 5.0;
	b = a < 6.0;
	if (b) {
		printf("%d\n", 6);
	}
	return;
}